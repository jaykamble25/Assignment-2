export class Students{

    constructor(public rollNo:number,public name:string,public percentage:number,public numberOfAttempts:number,public subjects:string[]){
        
    }

}